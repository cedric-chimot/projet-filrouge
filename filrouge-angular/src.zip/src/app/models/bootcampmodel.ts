export class Bootcamp{
    id!: number;
    dateDebut!: string;
    dateFin!: string;
    statut!: string;
    formation!: number;
    centreFormation!: number;

}
