import { Bootcamp } from "./bootcampmodel";

export class SousThemes {

}