export class Stagiaires {
    nom!: string;
    prenom!: string;
    telephone!: string;
    email!: string;
    pseudo!: string;
    mdp!: string;
    role!: string;
}