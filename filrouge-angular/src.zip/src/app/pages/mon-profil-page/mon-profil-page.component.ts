import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mon-profil-page',
  templateUrl: './mon-profil-page.component.html',
  styleUrls: ['./mon-profil-page.component.css']
})
export class MonProfilPageComponent {


}
