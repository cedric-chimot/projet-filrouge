export class Candidats {
    id!: number;
    nom!: string;
    prenom!: string;
    telephone!: string;
    email!: string;
    role!: string;
}