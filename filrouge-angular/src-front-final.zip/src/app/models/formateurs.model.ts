export class Formateurs {
    id!: number;
    nom!: string;
    prenom!: string;
    telephone!: string;
    email!: string;
    noteMoyenne!: number;
}