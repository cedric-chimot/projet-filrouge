export class Categorie {
    id!: number;
    nom!: string;
    description!: string;
}