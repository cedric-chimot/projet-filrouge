export class Stagiaire {
    id!: number;
    nom!: string;
    prenom!: string;
    telephone!: string;
    email!: string;
    role!: string;
}