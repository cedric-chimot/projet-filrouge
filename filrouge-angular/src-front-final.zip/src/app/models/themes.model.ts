import { SousThemes } from "./sousThemes.model";

export class Themes{
    id!: number;
    theme!: string;
    sousTheme!: SousThemes;
}
