export class User {
    id!: number;
    nom!: string;
    prenom!: string;
    telephone!: string;
    email!: string;
    pseudo!: string;
    mdp!: string;
    role!: string;
}