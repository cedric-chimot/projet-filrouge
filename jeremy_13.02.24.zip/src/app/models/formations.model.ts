
export class Formations {
  id!: number;
  nom!: string;
  prix!: number;
  description!: string;
}