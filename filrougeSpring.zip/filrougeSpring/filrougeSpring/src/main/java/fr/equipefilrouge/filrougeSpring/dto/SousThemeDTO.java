package fr.equipefilrouge.filrougeSpring.dto;

import lombok.Data;

@Data
public class SousThemeDTO {
    private String nomSousTheme;
    private Long themeId;

}
