package fr.equipefilrouge.filrougeSpring.repository;

import fr.equipefilrouge.filrougeSpring.entity.SousTheme;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SousThemeRepository extends JpaRepository<SousTheme, Long> {
}
