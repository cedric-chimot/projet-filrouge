package fr.equipefilrouge.filrougeSpring.dto;

import lombok.Data;

@Data
public class LieuDTO {
    private Long id;
    private String nom;
    private String adresse;

}
