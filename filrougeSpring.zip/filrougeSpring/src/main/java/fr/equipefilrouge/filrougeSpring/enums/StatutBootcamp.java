package fr.equipefilrouge.filrougeSpring.enums;

public enum StatutBootcamp {
    ANNULE,
    EN_COURS,
    TERMINE,
    EN_ATTENTE
}
