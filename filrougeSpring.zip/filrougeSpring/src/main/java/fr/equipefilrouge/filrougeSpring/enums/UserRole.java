package fr.equipefilrouge.filrougeSpring.enums;

public enum UserRole {
    ADMIN,
    STAGIAIRE,
    CANDIDAT,
    FORMATEUR
}
