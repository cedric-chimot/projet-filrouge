package fr.equipefilrouge.filrougeSpring.enums;

public enum SousThemesEnum {
    javascript,
    python,
    langage_web,
    Java,
    React,
    nodeJS,
    spring

}
