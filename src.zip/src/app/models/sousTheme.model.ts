import { Theme } from "./theme.model";

export class SousTheme {
    id!: number;
    nomSousTheme!: string;
    theme!: Theme;
}
