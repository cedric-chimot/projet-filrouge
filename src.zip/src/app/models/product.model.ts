export default interface Product {
    id: number;
    nom: string;
    img: string;
}