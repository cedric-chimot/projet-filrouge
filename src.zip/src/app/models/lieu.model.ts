export class Lieu {
    id!: number;
    raisonSociale!: string;
    codePostal!: string;
    rue!: string;
    ville!: string;
    pays!: string;
}